package com.example.pingpong.Controller;

public interface SceneToScene {

    void toGame();
    void toMenu();
}
