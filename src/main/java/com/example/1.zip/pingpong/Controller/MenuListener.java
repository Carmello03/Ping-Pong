package com.example.pingpong.Controller;

import com.example.pingpong.Model.Game;
import com.example.pingpong.View.GameView;
import javafx.application.Platform;
import javafx.scene.control.*;

import java.util.Optional;

public class MenuListener {
    private Game game;
    private SceneToScene toScene;
    private GameView gameview;
    public MenuListener(Game game, SceneToScene toScene, GameView gameview)
    {
        this.game = game;
        this.toScene = toScene;
        this.gameview = gameview;
    }

    public void setExit() {
        Platform.exit();
    }

    public void start() {
        toScene.toGame();
    }
    public void setAbout() {
        System.out.println("ABOUT");
        var alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Super Ping pong");
        alert.setHeaderText("Made in Cork");
        alert.setContentText("All rights resereved");
        alert.showAndWait().ifPresent((btnType) -> {
        });
    }
    public void setPlayer1Name() {
        TextInputDialog textInputDialog = new TextInputDialog();
        textInputDialog.setTitle("Enter Player Name");
        textInputDialog.setHeaderText("Changing Name for " + game.getPlayer1().getName() + ":");
        textInputDialog.setContentText("Please enter the new name for " + game.getPlayer1().getName() + ":");

        // Show the text input dialog to enter the new name
        Optional<String> newName = textInputDialog.showAndWait();

        newName.ifPresent(name -> {
            game.getPlayer1().setName(name);
        });
    }

    public void setPlayer2Name() {
        TextInputDialog textInputDialog = new TextInputDialog();
        textInputDialog.setTitle("Enter Player Name");
        textInputDialog.setHeaderText("Changing Name for " + game.getPlayer2().getName() + ":");
        textInputDialog.setContentText("Please enter the new name for " + game.getPlayer2().getName() + ":");

        // Show the text input dialog to enter the new name
        Optional<String> newName = textInputDialog.showAndWait();

        newName.ifPresent(name -> {
            game.getPlayer2().setName(name);
        });
    }

    public void setBallSpeed(int speed) {
        game.getBall().setSpeed(speed);
    }

    public void setRacketSize(int size) {
        game.getPlayer1().getRacket().setSize(size);
    }

    public void setWinningScore(int score) {
        // Set the winning score in the game model
    }

    public void setSpeedIncreaseFrequency(int frequency) {
        // Set the speed increase frequency in the game model
    }
}