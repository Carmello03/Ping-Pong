package com.example.pingpong.Model;

public class Ball {
    private int speed;
    private int speedIncreaseFrequency;
    private double radius;

    public Ball() {
        this.speed = 1;
        this.speedIncreaseFrequency = 1;
        this.radius = 15;
    }

    public Ball(int speed, int speedIncreaseFrequency, double radius) {
        this.speed = speed;
        this.speedIncreaseFrequency = speedIncreaseFrequency;
        this.radius = radius;
    }

    // Getter for speed
    public int getSpeed() {
        return speed;
    }

    // Setter for speed
    public void setSpeed(int speed) {
        this.speed = speed;
    }
    public int getSpeedIncreaseFrequency() {
        return speedIncreaseFrequency;
    }

    // Setter for speed
    public void setSpeedIncreaseFrequency(int speedIncreaseFrequency) {
        this.speedIncreaseFrequency = speedIncreaseFrequency;
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }
}