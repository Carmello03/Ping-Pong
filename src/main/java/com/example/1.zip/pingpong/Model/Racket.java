package com.example.pingpong.Model;

public class Racket {
    private int widht;
    private int lenght;
    private int size;

    public Racket() {
        this.widht = 60;
        this.lenght = 15;
    }

    public Racket(int width, int length) {
        this.widht = width;
        this.lenght = length;
    }

    public int getWidth() {
        return widht;
    }
    public void setWidht(int width) {
        this.widht = width;;
    }

    public int getLenght() {
        return lenght;
    }
    public void setLenght(int length) {
        this.widht = length;;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        switch (size) {
            case 1: // large
                this.size = 3;
                break;
            case 2: // medium
                this.size = 2;
                break;
            case 3: // small
                this.size = 1;
                break;
        }
    }
}