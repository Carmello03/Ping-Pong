package com.example.pingpong;

import com.example.pingpong.Controller.LabController;
import com.example.pingpong.Controller.MenuListener;
import com.example.pingpong.Controller.SceneToScene;
import com.example.pingpong.View.GameMenu;
import com.example.pingpong.View.GameView;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


public class PingPongGame extends Application implements SceneToScene {
    private LabController labController;
    private MenuListener menuListener;
    private GameMenu gameMenu;
    private GameView canvas;
    private final String title = "Ping Pong";

    @Override
    public void init() {
        canvas = new GameView(600, 400);
        labController = new LabController();

        if (labController.getGame() != null) {
            menuListener = new MenuListener(labController.getGame(), this, canvas);
            gameMenu = new GameMenu(menuListener);
            canvas.drawGame(labController.getGame());
        } else {
        }
    }

    @Override
    public void start(Stage primaryStage) {
        VBox root = gameMenu.getMenuMain();

        root.setAlignment(Pos.CENTER);
        Scene scene = new Scene(root, 600, 600);
        primaryStage.setTitle(title);

        primaryStage.setScene(scene);
        primaryStage.show();
    }
    @Override
    public void toMenu() {
        VBox root = gameMenu.getMenuMain();
        Scene menuMainScene = new Scene(root, 600, 600);
        Stage primaryStage = (Stage) canvas.getScene().getWindow();
        primaryStage.setScene(menuMainScene);
    }
    @Override
    public void toGame() {
        BorderPane borderPane = new BorderPane();
        borderPane.getChildren().add(canvas);
        HBox playersBox = new HBox(60);
        Label player1 = new Label(gameMenu.getSetPlayerName1().getText());
        Label player2 = new Label(gameMenu.getSetPlayerName2().getText());
        playersBox.getChildren().add(player1);
        playersBox.getChildren().add(player2);

        borderPane.setTop(playersBox);
        Scene gameScene = new Scene(borderPane, 600, 600);
        Stage primaryStage = (Stage) gameMenu.getMenuMain().getScene().getWindow();
        primaryStage.setScene(gameScene);
    }

    public static void main(String[] args) {
        launch(args);
    }

    public GameMenu getGameMenu() {
        return gameMenu;
    }

    public void setGameMenu(GameMenu gameMenu) {
        this.gameMenu = gameMenu;
    }

    public GameView getCanvas() {
        return canvas;
    }

    public void setCanvas(GameView canvas) {
        this.canvas = canvas;
    }

}