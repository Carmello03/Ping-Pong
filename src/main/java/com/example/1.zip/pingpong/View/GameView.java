package com.example.pingpong.View;

import com.example.pingpong.Model.*;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class GameView extends Canvas {
    private Game game;
    private double racketOffset = 10;

    public GameView(double width, double height) {
        super(width, height);
    }

    public void drawGame(Game game) {
        GraphicsContext gc = this.getGraphicsContext2D();
        drawBackground(gc);
        drawBall(gc);
        drawRacket(gc, game.getPlayer1().getRacket(), racketOffset); // Player 1 on left
        drawRacket(gc, game.getPlayer2().getRacket(), getWidth() - game.getPlayer2().getRacket().getWidth() - racketOffset); // Player 2 on right
        drawScore(gc, game.getPlayer1(), game.getPlayer2());    }

    private void drawRacket(GraphicsContext gc, Racket racket, double xPosition) {
        double yPosition = (getHeight() / 2) - (racket.getLenght() / 2.0);

        gc.setFill(Color.WHITE); // Assuming Racket class has a getColor() method
        gc.fillRect(xPosition, yPosition, racket.getWidth(), racket.getLenght());
    }

    private void drawBackground(GraphicsContext gc) {
        gc.setFill(Color.BLACK);
        gc.clearRect(0, 0, this.getWidth(), this.getHeight());
        gc.fillRect(0, 0, this.getWidth(), this.getHeight());
    }
    public void drawBall(GraphicsContext gc) {
        Ball ball = game.getBall(); // Assuming you have a getter for the ball in your Game class
        double radius = ball.getRadius(); // Use the radius from your Ball class
        double centerX = getWidth() / 2 - radius; // Center horizontally
        double centerY = getHeight() / 2 - radius; // Center vertically

        gc.setFill(Color.YELLOWGREEN);
        // Draw the ball using the center coordinates and the ball's radius
        gc.fillOval(centerX, centerY, radius * 2, radius * 2);
    }

    public void drawScore(GraphicsContext gc, Player player1, Player player2) {
        gc.setFill(Color.WHITE);
        String scoreText = player1.getScore() + " : " + player2.getScore();
        gc.fillText(scoreText, getWidth() / 2, 50);
    }
}