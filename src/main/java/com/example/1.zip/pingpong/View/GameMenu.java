package com.example.pingpong.View;

import com.example.pingpong.Controller.MenuListener;
import com.example.pingpong.Controller.SceneToScene;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class GameMenu {
    private MenuListener menuListener;
    private VBox menuMain;
    private Button start;

    //private Hbox menuGame;
    private TextField setPlayer1Name, setPlayer2Name, menuItemExit, menuItemAbout;
    private Slider setBallSpeed, setRacketSize, setWinningScore, setSpeedIncreaseFrequency;

    public GameMenu(MenuListener menuListener) {
        this.menuListener = menuListener;

        // Initialize menu items
        initializeMenu();

        start = new Button("START");

        // Add menu items to menu
        menuMain();

        // Handle menu item actions
        handleMenuAction();
    }

    public void initializeMenu() {
        setPlayer1Name = new TextField();
        setPlayer2Name = new TextField();
        setBallSpeed = new Slider(1, 10, 5);
        setRacketSize = new Slider(10, 100, 30);
        setWinningScore = new Slider(1, 21, 11);
        setSpeedIncreaseFrequency = new Slider(1, 10, 2);
        menuItemAbout = new TextField();
        menuItemExit = new TextField();
    }

    public void handleMenuAction() {
        setPlayer1Name.setOnAction(e -> menuListener.setPlayer1Name());
        setPlayer2Name.setOnAction(e -> menuListener.setPlayer2Name());
//        setBallSpeed.valueProperty().addListener((obs, oldVal, newVal) ->
//                menuListener.setBallSpeed(newVal.intValue()));
//        setRacketSize.valueProperty().addListener((obs, oldVal, newVal) ->
//                menuListener.setRacketSize(newVal.intValue()));
//        setWinningScore.valueProperty().addListener((obs, oldVal, newVal) ->
//                menuListener.setWinningScore(newVal.intValue()));
//        setSpeedIncreaseFrequency.valueProperty().addListener((obs, oldVal, newVal) ->
//                menuListener.setSpeedIncreaseFrequency(newVal.intValue()));
        menuItemExit.setOnAction(e -> menuListener.setExit());
        menuItemAbout.setOnAction(e -> menuListener.setAbout());
        start.setOnAction(e -> menuListener.start());
    }

    public void menuMain() {
        Label title = new Label("Ping-Pong");
        HBox players = new HBox(menuMainPlayers("Player 1 - ", setPlayer1Name),
                menuMainPlayers("Player 2 - ", setPlayer2Name));
        VBox settings = new VBox(7, menuMainSettings( "Set Ball Speed", setBallSpeed),
                menuMainSettings( "Set Racket Size", setRacketSize),
                menuMainSettings( "Set Winning Score", setWinningScore),
                menuMainSettings( "Set Speed Increase Frequency", setSpeedIncreaseFrequency),
                menuMainSettings( "About", menuItemAbout),
                menuMainSettings( "Exit", menuItemExit));
        this.menuMain = new VBox(10, title, players, settings, start);
        this.menuMain.setAlignment(Pos.CENTER);
    }

    public HBox menuMainSettings(String settingsLabel, javafx.scene.Node settingAction) {
        Label setting = new Label(settingsLabel);
        HBox settingsBox = new HBox(10, setting, settingAction);
        settingsBox.setAlignment(Pos.CENTER);
        return settingsBox;
    }

    public HBox menuMainPlayers(String label, TextField textField) {
        Label player = new Label(label);
        HBox playersBox = new HBox(10, player, textField);
        playersBox.setAlignment(Pos.CENTER);
        return playersBox;
    }

    // Getter for menuBar
    public VBox getMenuMain() {
        return menuMain;
    }

    public TextField getSetPlayerName1() {
        return setPlayer1Name;
    }

    public TextField getSetPlayerName2() {
        return setPlayer2Name;
    }
}
